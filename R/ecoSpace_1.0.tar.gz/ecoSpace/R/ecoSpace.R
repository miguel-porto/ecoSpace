.onLoad<-function(libname,pkgname) {
	test=try(getURL("localhost:7520"),silent=TRUE)
	if(inherits(test,"try-error")) {
		cat("ERROR: ecoSpace server not running!\n")
	} else {
		cat("Welcome to ecoSpace!\nExisting analyses:\n\n")
		print(get.datasets())
	}
}

start.server<-function(pathtoserver) {
	prevwd=getwd()
	setwd(pathtoserver)
	cmd=paste(pathtoserver,"/run start",sep="")
	system(cmd)
	setwd(prevwd)
}

stop.server<-function(pathtoserver) {
	prevwd=getwd()
	setwd(pathtoserver)
	cmd=paste(pathtoserver,"/run stop",sep="")
	system(cmd)
	setwd(prevwd)
}

distance.matrix<-function(dataset,analysis) {
	content=getBinaryURL(paste("localhost:7520/distdownload?did=",dataset,"&aid=",analysis,sep=""))
	tmp = tempfile()
	writeBin(content, con = tmp)
	load(tmp)
	return(distances)
}

get.variables<-function() {
	v=fromJSON(getURL("localhost:7520/getvariables"))
	rownames(v)=v[,1]
	v=v[,-1]
	return(v)
}

get.datasets<-function() {
	v=fromJSON(getURL("localhost:7520/getdatasets"))$datasets
	rownames(v)=v[,"id"]
	v=v[,!(colnames(v)=="id")]
	return(v)
}

get.analyses<-function(dataset) {
	v=fromJSON(getURL(paste("localhost:7520/getanalyses?did=",dataset,sep="")))$analyses
	rownames(v)=v[,"id"]
	v=v[,!(colnames(v)=="id")]
	return(v)
}

